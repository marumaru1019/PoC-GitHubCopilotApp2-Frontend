(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/76d55_b46ff34a._.js",
  "static/chunks/97c00_Desktop_business_github-copilot_docomo-handson-app_frontend_8bfc0668._.js"
],
    source: "dynamic"
});
