(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a41707b9._.css",
  "static/chunks/76d55_8c81d97f._.js",
  "static/chunks/97c00_Desktop_business_github-copilot_docomo-handson-app_frontend_927197bd._.js"
],
    source: "dynamic"
});
