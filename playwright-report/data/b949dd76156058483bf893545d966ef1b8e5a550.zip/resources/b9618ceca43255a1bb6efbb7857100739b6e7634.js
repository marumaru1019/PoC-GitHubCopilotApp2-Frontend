(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/76d55_5e5f2128._.js",
  "static/chunks/97c00_Desktop_business_github-copilot_docomo-handson-app_frontend_7126a82c._.js"
],
    source: "dynamic"
});
