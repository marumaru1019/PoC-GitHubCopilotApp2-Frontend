(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9b0b61fe._.js",
  "static/chunks/76d55_next_dist_compiled_react-dom_1a87d9d1._.js",
  "static/chunks/76d55_next_dist_compiled_next-devtools_index_f78337aa.js",
  "static/chunks/76d55_next_dist_compiled_b36ac7c8._.js",
  "static/chunks/76d55_next_dist_client_dfe25289._.js",
  "static/chunks/76d55_next_dist_8bb647b9._.js",
  "static/chunks/76d55_@swc_helpers_cjs_58042a8c._.js"
],
    source: "entry"
});
