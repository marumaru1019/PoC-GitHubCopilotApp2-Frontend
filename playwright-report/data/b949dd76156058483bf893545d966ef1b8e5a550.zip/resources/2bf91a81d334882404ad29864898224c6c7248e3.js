(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/app/providers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers,
    "useQueryClientContext",
    ()=>useQueryClientContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const QueryClientContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useQueryClientContext() {
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(QueryClientContext);
    if (!context) {
        throw new Error('useQueryClientContext must be used within Providers');
    }
    return context;
}
_s(useQueryClientContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function Providers(param) {
    let { children } = param;
    _s1();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Providers.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        staleTime: 60 * 1000,
                        refetchOnWindowFocus: false
                    }
                }
            })
    }["Providers.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QueryClientContext.Provider, {
            value: queryClient,
            children: children
        }, void 0, false, {
            fileName: "[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/app/providers.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/app/providers.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_s1(Providers, "PD+UB9ABGiWRE3jY1746zf8+tQI=");
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/lib/api-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiClient",
    ()=>apiClient,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000") || 'http://localhost:8000';
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Add token to requests
apiClient.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem('accessToken');
        if (token) {
            config.headers.Authorization = "Bearer ".concat(token);
        }
    }
    return config;
});
// Handle 401 errors
apiClient.interceptors.response.use((response)=>response, (error)=>{
    var _error_response;
    if (((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) === 401) {
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem('accessToken');
            window.location.href = '/login';
        }
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = apiClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/lib/auth-context.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/lib/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$app$2f$providers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/app/providers.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider(param) {
    let { children } = param;
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$app$2f$providers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClientContext"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            loadUser();
        }
    }["AuthProvider.useEffect"], []);
    const loadUser = async ()=>{
        const token = localStorage.getItem('accessToken');
        if (!token) {
            setLoading(false);
            return;
        }
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/api/auth/me');
            setUser(response.data);
        } catch (error) {
            localStorage.removeItem('accessToken');
        } finally{
            setLoading(false);
        }
    };
    const login = async (credentials)=>{
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/auth/login', credentials);
        const { access_token } = response.data;
        localStorage.setItem('accessToken', access_token);
        await loadUser();
        router.push('/');
    };
    const logout = async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/auth/logout');
        } catch (error) {
        // Ignore logout errors
        }
        localStorage.removeItem('accessToken');
        setUser(null);
        // Clear React Query cache to prevent data leakage between users
        queryClient.clear();
        router.push('/login');
    };
    const hasRole = function() {
        for(var _len = arguments.length, roles = new Array(_len), _key = 0; _key < _len; _key++){
            roles[_key] = arguments[_key];
        }
        return user ? roles.includes(user.role) : false;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            loading,
            login,
            logout,
            isAuthenticated: !!user,
            hasRole
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/OneDrive - Microsoft/Desktop/business/github-copilot/docomo-handson-app/frontend/lib/auth-context.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "PRrW31on7oieuiOJBfYg8RfXfL4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$app$2f$providers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClientContext"]
    ];
});
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Microsoft$2f$Desktop$2f$business$2f$github$2d$copilot$2f$docomo$2d$handson$2d$app$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=97c00_Desktop_business_github-copilot_docomo-handson-app_frontend_927197bd._.js.map